﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OnlineShop.IO
{
    public interface IReader
    {
        string CustomReadLine();
    }
}
