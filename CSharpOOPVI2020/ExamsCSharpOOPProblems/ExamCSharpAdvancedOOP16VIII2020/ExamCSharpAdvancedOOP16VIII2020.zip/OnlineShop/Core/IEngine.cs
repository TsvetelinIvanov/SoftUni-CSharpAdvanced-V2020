﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OnlineShop.Core
{
    public interface IEngine
    {
        void Run();
    }
}
