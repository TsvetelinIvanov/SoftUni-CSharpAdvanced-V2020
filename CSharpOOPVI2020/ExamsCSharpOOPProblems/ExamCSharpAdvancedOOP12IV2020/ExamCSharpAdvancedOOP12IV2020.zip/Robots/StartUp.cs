﻿using System;

namespace Robots
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
