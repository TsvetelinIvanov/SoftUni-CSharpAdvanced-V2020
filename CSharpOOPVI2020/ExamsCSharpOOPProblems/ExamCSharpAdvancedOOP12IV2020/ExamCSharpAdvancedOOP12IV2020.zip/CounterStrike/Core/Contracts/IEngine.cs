﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CounterStrike.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
