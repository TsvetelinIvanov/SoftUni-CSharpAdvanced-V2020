﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CounterStrike.Utilities.Messages
{
    public static class OutputMessages
    {
        public const string SuccessfullyAddedPlayer = "Successfully added player {0}.";

        public const string SuccessfullyAddedGun = "Successfully added gun {0}.";
    }
}
