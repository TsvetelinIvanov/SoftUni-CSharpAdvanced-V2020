﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SantaWorkshop.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
