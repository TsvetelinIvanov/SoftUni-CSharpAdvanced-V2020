﻿using SantaWorkshop.IO.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace SantaWorkshop.IO
{
    public class Reader : IReader
    {
        public string ReadLine()
        {
            return Console.ReadLine();
        }
    }
}
