﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SantaWorkshop.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
