﻿using SantaWorkshop.Models.Dwarfs.Contracts;
using SantaWorkshop.Models.Presents.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace SantaWorkshop.Models.Workshops.Contracts
{
    public interface IWorkshop
    {
        void Craft(IPresent present, IDwarf dwarf);
    }
}
