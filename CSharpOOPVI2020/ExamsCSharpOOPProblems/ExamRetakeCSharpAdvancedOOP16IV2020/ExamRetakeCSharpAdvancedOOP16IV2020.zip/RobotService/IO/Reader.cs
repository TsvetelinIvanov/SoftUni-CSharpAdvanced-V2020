﻿using RobotService.IO.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace RobotService.IO
{
    public class Reader : IReader
    {
        public string ReadLine()
        {
            return Console.ReadLine();
        }
    }
}
