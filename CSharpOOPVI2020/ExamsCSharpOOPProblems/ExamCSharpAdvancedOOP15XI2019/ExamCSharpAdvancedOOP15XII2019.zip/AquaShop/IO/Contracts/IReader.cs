﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AquaShop.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
