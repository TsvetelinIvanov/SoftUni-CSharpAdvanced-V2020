﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AquaShop.Models.Decorations.Contracts
{
    public interface IDecoration
    {
        int Comfort { get; }

        decimal Price { get; }
    }
}
