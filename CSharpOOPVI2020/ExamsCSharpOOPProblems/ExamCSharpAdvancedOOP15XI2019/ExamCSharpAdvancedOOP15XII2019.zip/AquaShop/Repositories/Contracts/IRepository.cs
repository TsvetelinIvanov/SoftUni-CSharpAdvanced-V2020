﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AquaShop.Repositories.Contracts
{
    public interface IRepository<T>
    {
        IReadOnlyCollection<T> Models { get; }

        void Add(T model);

        bool Remove(T model);

        T FindByType(string type);
    }
}
